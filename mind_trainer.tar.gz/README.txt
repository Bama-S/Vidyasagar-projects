Method 1:

1.Copy the source code folder in any of the directory.

2.Goto to the command prompt.

3.Set path="C:\Program Files\Java\jdk1.6.0\bin"

4.Compile the source code using the command - javac *.java

5.Run the code using the command - java main

Method 2:

1.Open the Mind Trainer folder

2.Double click the mindtrainer1 executable jar file.