public class Test
{  
 public static void main(String[]args)  
 {  
  System.out.println("\u221A"); 
  System.out.println( "\u221A1\u03052\u0305"); 
 }  
}  
