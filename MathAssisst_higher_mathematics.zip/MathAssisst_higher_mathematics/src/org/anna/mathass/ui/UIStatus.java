package org.anna.mathass.ui;

public class UIStatus {
	
	public  boolean Visible=false;
	public  int focused=0;
}
